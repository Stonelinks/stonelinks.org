#!/usr/bin/env python

# Lucas Doyle wrote this

import subprocess
import string
import sys
import pylab  # matplotlib

def timerun(program, args) :
    print 'Starting timed execution of ' + program + ' with ' + str(len(args)) + ' arguments.'
    i = 1
    
    # Execute program, once for each n argument
    for n in args :
        
        # This was really annoying. Build the arguments to the time system call to the time command.
        # First of all, for whatever reason 'time' didn't work correctly with any arguments other than -p, 
        # so I used /usr/bin/time instead. Since I could not figure out why the output of 'time' was not
        # coming back to stdin, I use the -o (output file) and -a (append) option to just output the real
        # execution time ( thats where '-f' and '%e' comes from ) to the file.
        p = subprocess.Popen(['/usr/bin/time', '-o', 'runtimes.txt', '-a', '-f', '%e', './' + program, str(n)], stdout=subprocess.PIPE)
        
        # Read back from stdin, print where we are (not required, but its nice)
        output = p.communicate()[0]
        sys.stdout.write( str(i) + ':\tfib('+ str(n) + ') = ' + output)
        i += 1
    print 'done'
    
    # Open up, read and return the times in the output file
    f = open('runtimes.txt', 'r')
    times = f.read().splitlines()

    # Clean up old runtimes
    subprocess.Popen(['rm', 'runtimes.txt'],stdout=subprocess.PIPE)
    
    return times

def main():
    
    # Arguments we are interested in testing runtimes for
    # args = 1, 5, 10, 15, 20, 25, 30, 35, 40, 41, 42, 43, 44, 45, 46, 47, 48
    args = range(1, 56)
    
    
    
    # Compute the runtimes of the recursive algorithm, then the iterative one
    rtimes = timerun('rfib', args)
    itimes = timerun('ifib', args)

    # Plot it with pylab
    pylab.xlabel('N')
    pylab.ylabel('Time to compute fib(N) (seconds)')
    pylab.title('Recursive vs. Iterative Execution Time for Fibionacci Sequence')
    pylab.plot(args, rtimes, 'ro-', label='Recursive')
    pylab.plot(args, itimes, 'bo-', label='Iterative')
    pylab.legend()

    # other drawing styles for plots in pylab:
    # 'r' red line, 'g' green line, 'y' yellow line 
    # 'ro' red dots as markers, 'r.' smaller red dots, 'r+' red pluses
    # 'r--' red dashed line, 'g^' green triangles, 'bs' blue squares
    # 'rp' red pentagons, 'r1', 'r2', 'r3', 'r4' well, check out the markers

    # save the plot as a PNG image
    pylab.savefig('Fig.png')

    # show the pylab plot window
    pylab.show()

if __name__ == "__main__":
    main()
