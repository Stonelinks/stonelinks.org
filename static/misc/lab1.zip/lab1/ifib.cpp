#include <iostream>
#include <cstdlib> 

int fib(int n)
{
    int n1 = 0; // First term in the sum (n-1)
    int n2 = 1; // Second term in the sum (n-2)
    int i = 0; // Counter
    int sum = 1; // Current sum
    int oldsum = 0; // Old sum
    
    // Do it a million times cause Das says so
    for (int j = 0; j < 1000000; j++)
    {
        while (i < n)
        {
            n1 = n2; // Reassign old second term to new first term
            n2 = oldsum; // Reassign old sum to new second term
            sum = n1 + n2; // Add terms
            oldsum = sum; // Record sum for next iteration
            i++;
        }
    }
    return sum;
}

int main(int argc, char* argv[])
{
    // handle command line arguments
    // most of this stuff is standard by now
    if ( argc != 2 )
    {
        std::cerr << "Usage: " << argv[0] << " n\n";
        return 1;
    }
    
    int n = atoi(argv[1]);
    std::cout << fib(n) << " \n";
    
    return 0;
}
